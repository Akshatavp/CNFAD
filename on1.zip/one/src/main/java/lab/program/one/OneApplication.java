package lab.program.one;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class OneApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneApplication.class, args);
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext(AppConfig.class);
		
		Customer c=ac.getBean(Customer.class);
		Ticket t= ac.getBean(Ticket.class);
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Customer Details");
		System.out.println("Enter Customer name");
		c.setName(sc.nextLine());
		System.out.println("Enter Customer Address");
		c.setAddress(sc.nextLine());
		
		System.out.println("Enter ticket details");
		System.out.println("Enter ticket no");
		t.setTicketno(sc.nextInt());
		System.out.println("Enter price");
		t.setPrice(sc.nextInt());
		System.out.println("Enter Seat no");
		t.setSeatno(sc.nextInt());
		
		System.out.println("Enter Ticket Type");
		t.setTictype(sc.nextLine());
		
		
		System.out.println("Customer Details");
		System.out.println("Customer name :"+c.getName());
		System.out.println("Customer Address :"+c.getAddress());
		
		System.out.println("Ticket Details");
		System.out.println("Ticket number :"+t.getTicketno());
		System.out.println("Ticket price :"+t.getPrice());
		System.out.println("Seat No:"+t.getSeatno());
		
		System.out.println("Ticket Type :"+t.getTictype());
		
		
		
		
	}

}
