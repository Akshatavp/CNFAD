package lab.program.one;

public class Ticket {
	int Ticketno, price, seatno;
	String tictype;
	public int getTicketno() {
		return Ticketno;
	}
	public void setTicketno(int ticketno) {
		Ticketno = ticketno;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSeatno() {
		return seatno;
	}
	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}
	public String getTictype() {
		return tictype;
	}
	public void setTictype(String tictype) {
		this.tictype = tictype;
	}
	

}
