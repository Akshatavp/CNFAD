package lab.program.one;

public class Customer {
String name, address;
Ticket ticks;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Ticket getTicks() {
	return ticks;
}
public void setTicks(Ticket ticks) {
	this.ticks = ticks;
}

}
