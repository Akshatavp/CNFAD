package lab.program.two;

import java.util.Scanner;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class TwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwoApplication.class, args);
		Scanner sc=new Scanner(System.in);
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("coldept.xml");
		Department dt=(Department)ac.getBean("department");
		
		while(true) {
			System.out.println("1.Enter Department details 2.Display Department details with college Details 3.Exit");
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
			
			switch(ch) {
				case 1:
					System.out.println("Enter Department name");
					dt.setName(sc.next());
					System.out.println("Enter Department Description");
					dt.setDescription(sc.next());
					System.out.println("Enter Department id");
					dt.setId(sc.nextInt());
					break;
				case 2:
					System.out.println("The Department details alomg with College Details are");
					System.out.println(dt.getName()+" "+dt.getId()+" "+dt.getDescription());
					College cg=dt.getCollege();
					System.out.println(cg.getName()+" "+cg.getAddress());
					break;
				case 3:
					System.exit(0);
					
			}
			
		}
			
			
		
		
	}

}
